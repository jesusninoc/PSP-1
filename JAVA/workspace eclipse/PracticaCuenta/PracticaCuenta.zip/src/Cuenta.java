
public class Cuenta {

	private int numero=0;
	
	public synchronized void get(int reintegro){
		if((numero - reintegro)<=0){
			System.out.println("No puedes sacar tanto dinero");
		}
		while((numero - reintegro)<=0){
			try {
				wait();
			}catch (InterruptedException e){};
		}
		numero = numero - reintegro;
		notifyAll();
		//return numero; //no hay numero 
	}

	public synchronized void put(int valor){
		
		notifyAll();
		numero+=valor;
		
	}
	
	public synchronized String obtenerSaldo (){
		String saldo="";
		
		saldo = "Saldo actual "+numero+"€";
		notifyAll();
		return saldo;
	}

}
